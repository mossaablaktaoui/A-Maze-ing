from __future__ import annotations
import sys
from enum import Enum
from typing import Any, Dict, Optional, Tuple

from pydantic import (BaseModel, Field, ConfigDict, field_validator,
                      model_validator, ValidationError, ValidationInfo)


class Algorithm(str, Enum):
    dfs = "dfs"
    prim = "prim"
    hak = "hak"


def read_kv_config(path: str) -> Dict[str, str]:
    cfg: Dict[str, str] = {}
    with open(path, "r", encoding="utf-8") as f:
        for raw in f:
            line = raw.strip()
            if not line or line.startswith("#"):
                continue
            if "=" not in line:
                print(f"This line isn't as the expected '{line}'")
                continue
            key, value = line.split("=", 1)
            key = key.strip().upper()
            value = value.strip()

            # strip inline comments (optional)
            if "#" in value:
                value = value.split("#", 1)[0].strip()

            cfg[key] = value
    return cfg


class MazeConfig(BaseModel):

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

    width: int = Field(ge=3)
    height: int = Field(ge=3)

    entry: Tuple[int, int] = Field((0, 0))
    exit_: Tuple[int, int]

    perfect: bool = Field(True)
    output_file: str = Field("maze.txt", min_length=1)

    algorithm: Algorithm = Field(Algorithm.dfs)
    animation: bool = Field(False)

    seed: Optional[int] = Field(None)
    padding: int = Field(20, ge=0)
    cell_size: int = Field(50, ge=1)

    @field_validator("width", "height", "padding", "cell_size", mode="before")
    @classmethod
    def parse_ints(cls, value: Any, info: ValidationInfo) -> Any:
        if info.field_name in ['width', 'height'] and value is None:
            raise ValueError("config file must have this key")
        if isinstance(value, int):
            return value
        if isinstance(value, str):
            key = value.strip()
            return int(key)  # will raise ValueError -> pydantic error
        return value

    @field_validator("perfect", "animation", mode="before")
    @classmethod
    def parse_bools(cls, value: Any) -> Any:
        if isinstance(value, bool):
            return value
        if isinstance(value, str):
            key = value.strip().lower()
            if key in {"true", "1", "yes", "y", "on"}:
                return True
            if key in {"false", "0", "no", "n", "off"}:
                return False
        return value  # let pydantic raise a good error

    @field_validator("entry", "exit_", mode="before")
    @classmethod
    def parse_pair(cls, value: Any) -> Any:
        if value is None:
            raise ValueError("config file must have this key")
        if isinstance(value, tuple):
            return value
        if isinstance(value, str):
            parts = [p.strip() for p in value.split(",")]
            if len(parts) != 2:
                raise ValueError("must be in format x,y")
            return (int(parts[0]), int(parts[1]))
        return value

    @field_validator("seed", mode="before")
    @classmethod
    def parse_seed(cls, value: Any) -> Any:
        if value is None:
            return None
        if isinstance(value, int):
            return value
        if isinstance(value, str):
            seed = value.strip()
            if seed == "" or seed.lower() == "none":
                return None
            return int(seed)
        return value

    @model_validator(mode="after")
    def validate_bounds_and_defaults(self) -> "MazeConfig":
        entry_x, entry_y = self.entry
        if not (0 <= entry_x < self.width and 0 <= entry_y < self.height):
            raise ValueError("ENTRY must be within maze bounds")

        exit_x, exit_y = self.exit_
        if not (0 <= exit_x < self.width and 0 <= exit_y < self.height):
            raise ValueError("EXIT must be within maze bounds")

        if self.entry == self.exit_:
            raise ValueError("ENTRY and EXIT must be different")

        if self.seed is not None and self.seed < 0:
            raise ValueError("SEED must be non-negative or None")

        return self

    @classmethod
    def from_file(cls, path: str) -> "MazeConfig":
        raw = read_kv_config(path)

        mapped: Dict[str, Any] = {
            "width": raw.get("WIDTH", None),
            "height": raw.get("HEIGHT", None),
            "entry": raw.get("ENTRY", None),
            "exit_": raw.get("EXIT", None),
            "perfect": raw.get("PERFECT", "true"),
            "output_file": raw.get("OUTPUT_FILE", "maze.txt"),
            "algorithm": raw.get("ALGORITHM", "dfs"),
            "animation": raw.get("ANIMATION", "true"),
            "seed": raw.get("SEED", None),
            "padding": raw.get("PADDING", 20),
            "cell_size": raw.get("CELL_SIZE", 50),
        }

        # Let pydantic validate everything and produce rich errors
        return cls.model_validate(mapped)

    @classmethod
    def read_config(cls, config_file_path: str) -> "MazeConfig":
        try:
            return cls.from_file(config_file_path)
        except FileNotFoundError:
            print(f"Error: configuration file not found: {config_file_path}")
            sys.exit(1)
        except ValidationError as validation_error:
            print(f"\nConfiguration error in '{config_file_path}':")
            for error in validation_error.errors():
                if 'loc' in error and len(error['loc']) > 0:
                    print("  ", error['loc'][0], end=": ")
                if 'ctx' in error and 'error' in error['ctx']:
                    print(error['ctx']['error'])
                else:
                    print(error['msg'])
            sys.exit(1)
